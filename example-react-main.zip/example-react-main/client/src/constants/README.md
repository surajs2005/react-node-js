## Constants folder


`Includes file constants for app :`

> Import/Export on Demand - Tree shaking.

> Declare constants capitalized name
 