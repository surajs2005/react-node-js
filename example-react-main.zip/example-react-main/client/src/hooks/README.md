## Hooks folder


`Includes file hooks ( reused code logic ) for app :`

> Use names that start with "use" - usePost.

> Note: with react we need attention re-render.
 