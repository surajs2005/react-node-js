## Assets folder

> / icons

> / images

> / fonts

`Recommended :`
```bash

# Standard file naming

example : 
  - app_ic_topic
  - app_im_topic
```