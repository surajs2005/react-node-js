## Utilities folder

`Includes file utils ( implement code support for function or business ) for app :`

> Define function support and maybe reused.

> Import/Export on Demand - Tree shaking.
