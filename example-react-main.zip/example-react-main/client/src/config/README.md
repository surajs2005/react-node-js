## Config folder


`Includes file config for app :`
```bash
example : 
  - config api fetch data.
  - cofig firebase cloud.
  - ...etc.
```