## Router folder

`Includes file config router for app :`

> Define router for app.
 
> Define rule for each route.

> Implement loading all for routes.